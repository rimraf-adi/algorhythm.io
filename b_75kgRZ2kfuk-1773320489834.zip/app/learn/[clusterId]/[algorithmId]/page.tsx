'use client';

import { curriculum } from '@/lib/algorithms';
import { ClusterSelector } from '@/components/learn/cluster-selector';
import { VisualizationArea } from '@/components/learn/visualization-area';
import { InfoPanel } from '@/components/learn/info-panel';
import { redirect } from 'next/navigation';

interface AlgorithmPageProps {
  params: {
    clusterId: string;
    algorithmId: string;
  };
}

export default function AlgorithmPage({ params }: AlgorithmPageProps) {
  const cluster = curriculum.clusters.find(c => c.id === params.clusterId);

  if (!cluster) {
    redirect('/learn');
  }

  const algorithm = cluster.algorithms.find(a => a.id === params.algorithmId);

  if (!algorithm) {
    redirect(`/learn/${params.clusterId}`);
  }

  return (
    <div className="flex h-screen">
      {/* Left Sidebar - Curriculum */}
      <ClusterSelector
        selectedClusterId={params.clusterId}
        selectedAlgorithmId={params.algorithmId}
      />

      {/* Center - Canvas & Controls */}
      <VisualizationArea 
        algorithm={algorithm}
        rightPanel={(currentStep) => (
          <InfoPanel 
            algorithm={algorithm} 
            currentStep={algorithm.steps[currentStep]}
          />
        )}
      />
    </div>
  );
}
